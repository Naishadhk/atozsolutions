import { Component, OnInit } from '@angular/core';
import { AdduserModel } from '../model/adduser-model';
import { AdduserService } from '../services/adduser.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  userSearched: AdduserModel;
  constructor(private route: ActivatedRoute, private router: Router,private Service:AdduserService) { 
    this.userSearched = new AdduserModel();
  }

  ngOnInit() {
  }

  search(id:number)
  {
    this.userSearched = this.Service.search(id);
  }
  // search(firstname:string)
  // {
  //   this.userSearched = this.Service.search(firstname);
  // }

  goBack() {
    this.router.navigate(['/home']);
  }

}
