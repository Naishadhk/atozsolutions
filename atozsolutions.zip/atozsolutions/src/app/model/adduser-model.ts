export class AdduserModel {
    id:number;
    firstname: String;
    lastname: String;
    email: String;
    
}