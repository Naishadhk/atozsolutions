import { Component, OnInit } from '@angular/core';
import { AdduserModel } from '../model/adduser-model';
import { ActivatedRoute, Router } from '@angular/router';
import { AdduserService } from '../services/adduser.service';
import {filter} from 'rxjs/operators';

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent implements OnInit {

  editedUser: AdduserModel;
  paramIndex;
  constructor(private route: ActivatedRoute, private router: Router, private Service: AdduserService) {
    this.editedUser = new AdduserModel();
  }

  ngOnInit() {
    if (window.location.search !== '') {
      // take id from route query param and prefill data of particular task
      this.route.queryParams.pipe(
      filter(params => params.id))
      .subscribe(params => {
      console.log(params.id);
      this.paramIndex = params.id;
      this.editedUser = this.Service.getDetailsOf(this.paramIndex);
      });
    }
  }
  editUser() {
    // send index of task and updated details
    this.Service.edit(this.paramIndex, this.editedUser);
    this.router.navigate(['/home']);
  }
  goBack() {
    this.router.navigate(['/home']);
  }

 
}
