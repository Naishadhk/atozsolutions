import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { AdduserModel } from '../model/adduser-model';
import { AdduserService } from '../services/adduser.service';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {

  new: AdduserModel;
  constructor(private router: Router, private Service: AdduserService) {
      this.new = new AdduserModel();
      
      
   }

  ngOnInit() {
  }
  goBack() {
    this.router.navigate(['/home']);
  }
  addUser() {
    this.Service.add(this.new);
  }
}
