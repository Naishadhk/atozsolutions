import { Component, OnInit } from '@angular/core';
import { AdduserModel } from '../model/adduser-model';
import { Router } from '@angular/router';
import { AdduserService } from '../services/adduser.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  // constructor() { }

  // ngOnInit() {
  // }

  allusers: AdduserModel[];
  confirmationStatus;
  constructor(private router: Router, private Service: AdduserService) {
    this.allusers = [];
    this.allusers = this.Service.Array;
  }

  ngOnInit() {
  }
  addTask() {
    // navigate to home page on click of Go to Home button
     
    this.router.navigate(['/create']);
  }
  deleteUser(index: number) {
    // ask user confirmation on delete
    this.confirmationStatus = confirm('Do you want to delete the task?');
    if (this.confirmationStatus) {
      this.Service.delete(index);
    }
  }
  editUser(index: number) {
    this.Service.editUser(index);
  }
  searchUser(index: number) {
   
  this.router.navigate(['/search']);
  
  }
  navigateToLogin() {
    // navigate to login page on click of login button
    this.router.navigate(['/login']);
  }
  navigateToAdduser() {
    // navigate to login page on click of login button
    this.router.navigate(['/adduser']);
  }

  sortUserByName()
  {
    this.Service.sortUserByName();
  }

  sortUserById()
  {
    this.Service.sortUserById();
  }
}
