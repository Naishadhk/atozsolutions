import { Injectable } from '@angular/core';
import {Router} from '@angular/router';
import { AdduserModel } from '../model/adduser-model';




@Injectable({
  providedIn: 'root'
})
export class AdduserService {
  Array: AdduserModel[];
  constructor(private router: Router) {
    this.Array = [];
  }
  add(user: AdduserModel) {
    // add task to array
    user.id= Math.floor(Math.random() * 100);
    this.Array.push(user);
    this.router.navigate(['/home']);
  }
  display() {
    return this.Array;
  }
  delete(index: number) {
    // delete a particular task
    this.Array.splice(index, 1);
  }
  editUser(index: number) {
    // add id of task through route to prefill and edit particular task
  this.router.navigate(['/edituser'], { queryParams: { id: index }});
  
  }
  
  getDetailsOf(index) {
    // get details of particular task
    return this.Array[index];
  }
  edit(index: number, updatedTask: AdduserModel) {
    // update edited task details to array
    this.Array[index] = updatedTask;
    
  }
  search(id: number) {
    // this.router.navigate(['/search']);
    var result = this.Array.find(x => x.id == id);
    if (result == null)
      return null; //if not found
    else
      return result; //if found then store it
  }

  // search(firstname: string) {
  //   // this.router.navigate(['/search']);
  //   var result = this.Array.find(x => x.firstname == firstname);
  //   if (result == null)
  //     return null; //if not found
  //   else
  //     return result; //if found then store it
  // }


  sortUserByName()
  {
    this.Array.sort((a,b)=>a.firstname.localeCompare(b.firstname.valueOf()));
    return this.Array;
  }

  sortUserById() {
    this.Array.sort((a, b) => a.id - b.id);
    return this.Array;
  }
}
